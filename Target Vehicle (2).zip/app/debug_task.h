#ifndef __DEFBUG_TASK_H__
#define __DEFBUG_TASK_H__

void debug_task(void const *argu);

#endif
